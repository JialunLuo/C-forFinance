//
//  NPV.h
//  HW 3
//
//  Created by Jialun Luo on 9/17/18.
//  Copyright © 2018 Jialun Luo. All rights reserved.
//

//rRiskFreeRate is a global variable initiated in NPV.cpp
extern double gRiskFreeRate;
double riskfree_NPV(double, double);
double Risky_NPV(double, double, double);
