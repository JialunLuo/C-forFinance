//
//  my_area.h
//  HW 2
//
//  Created by Jialun Luo on 9/11/18.
//  Copyright © 2018 Jialun Luo. All rights reserved.
//

//area of a circle given its radius
double area(double);

//area of a rectangle given its width and length
double area(double,double);

//area of a triangle given lengths of 2 sides and the angle between these two sides
double area(double, double, double);
