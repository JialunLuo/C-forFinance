//
//  my_volume.hpp
//  HW 2
//
//  Created by Jialun Luo on 9/11/18.
//  Copyright © 2018 Jialun Luo. All rights reserved.
//

//volume of sphere given its radius
double volume(double);
//volume of a cylinder given its radius and height
double volume(double, double);
//volume of a rectangular prism given its width, length, and height
double volume(double, double, double);
