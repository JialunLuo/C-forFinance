//
//  sorting.hpp
//  Sorting
//
//  Created by Jialun Luo on 9/30/18.
//  Copyright © 2018 Jialun Luo. All rights reserved.
//


#include <stdio.h>
#include <string>
using namespace std;

void mySort(char arr[], int size_of_array);


void mySort(double arr[], int size_of_array);


void mySort(string arr[], int size_of_array);

void mySwap(double &ra, double &rb);

void mySwap(char &ra, char &rb);

void mySwap(string &ra, string &rb);


int size_of_array;
