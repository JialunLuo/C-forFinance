//
//  vector.hpp
//  Vector
//
//  Created by Jialun Luo on 10/2/18.
//  Copyright © 2018 Jialun Luo. All rights reserved.
//

void addVectors(double vec1[], double vec2[], double sum[], int size);
   
double lenVector(double vec[], int size);

double dotVectors(double vec1[], double vec2[], int size, double &angle);
